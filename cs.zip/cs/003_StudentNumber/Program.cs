﻿int studentNumber;
string name;

Console.WriteLine("학번을 입력하시오.");
studentNumber = int.Parse(Console.ReadLine());

Console.WriteLine("이름을 입력하시오.");
name = Console.ReadLine();

Console.WriteLine(studentNumber);
Console.WriteLine(name);