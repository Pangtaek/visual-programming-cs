﻿namespace _026_ScoreCal
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_course1 = new System.Windows.Forms.TextBox();
            this.txt_course2 = new System.Windows.Forms.TextBox();
            this.txt_course3 = new System.Windows.Forms.TextBox();
            this.txt_course5 = new System.Windows.Forms.TextBox();
            this.txt_course6 = new System.Windows.Forms.TextBox();
            this.txt_course4 = new System.Windows.Forms.TextBox();
            this.txt_course7 = new System.Windows.Forms.TextBox();
            this.cmb_1 = new System.Windows.Forms.ComboBox();
            this.cmb_2 = new System.Windows.Forms.ComboBox();
            this.cmb_3 = new System.Windows.Forms.ComboBox();
            this.cmb_4 = new System.Windows.Forms.ComboBox();
            this.cmb_5 = new System.Windows.Forms.ComboBox();
            this.cmb_6 = new System.Windows.Forms.ComboBox();
            this.cmb_7 = new System.Windows.Forms.ComboBox();
            this.cmb_14 = new System.Windows.Forms.ComboBox();
            this.cmb_13 = new System.Windows.Forms.ComboBox();
            this.cmb_12 = new System.Windows.Forms.ComboBox();
            this.cmb_11 = new System.Windows.Forms.ComboBox();
            this.cmb_10 = new System.Windows.Forms.ComboBox();
            this.cmb_9 = new System.Windows.Forms.ComboBox();
            this.cmb_8 = new System.Windows.Forms.ComboBox();
            this.lbl_result = new System.Windows.Forms.Label();
            this.txt_result = new System.Windows.Forms.TextBox();
            this.btn_result = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(133, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "과목명";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(320, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "학점";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(475, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "성적";
            // 
            // txt_course1
            // 
            this.txt_course1.Location = new System.Drawing.Point(92, 61);
            this.txt_course1.Name = "txt_course1";
            this.txt_course1.Size = new System.Drawing.Size(142, 28);
            this.txt_course1.TabIndex = 3;
            // 
            // txt_course2
            // 
            this.txt_course2.Location = new System.Drawing.Point(92, 104);
            this.txt_course2.Name = "txt_course2";
            this.txt_course2.Size = new System.Drawing.Size(142, 28);
            this.txt_course2.TabIndex = 4;
            // 
            // txt_course3
            // 
            this.txt_course3.Location = new System.Drawing.Point(92, 147);
            this.txt_course3.Name = "txt_course3";
            this.txt_course3.Size = new System.Drawing.Size(142, 28);
            this.txt_course3.TabIndex = 5;
            // 
            // txt_course5
            // 
            this.txt_course5.Location = new System.Drawing.Point(92, 233);
            this.txt_course5.Name = "txt_course5";
            this.txt_course5.Size = new System.Drawing.Size(142, 28);
            this.txt_course5.TabIndex = 6;
            // 
            // txt_course6
            // 
            this.txt_course6.Location = new System.Drawing.Point(92, 276);
            this.txt_course6.Name = "txt_course6";
            this.txt_course6.Size = new System.Drawing.Size(142, 28);
            this.txt_course6.TabIndex = 7;
            // 
            // txt_course4
            // 
            this.txt_course4.Location = new System.Drawing.Point(92, 190);
            this.txt_course4.Name = "txt_course4";
            this.txt_course4.Size = new System.Drawing.Size(142, 28);
            this.txt_course4.TabIndex = 9;
            // 
            // txt_course7
            // 
            this.txt_course7.Location = new System.Drawing.Point(92, 319);
            this.txt_course7.Name = "txt_course7";
            this.txt_course7.Size = new System.Drawing.Size(142, 28);
            this.txt_course7.TabIndex = 24;
            // 
            // cmb_1
            // 
            this.cmb_1.FormattingEnabled = true;
            this.cmb_1.Location = new System.Drawing.Point(289, 61);
            this.cmb_1.Name = "cmb_1";
            this.cmb_1.Size = new System.Drawing.Size(121, 26);
            this.cmb_1.TabIndex = 25;
            // 
            // cmb_2
            // 
            this.cmb_2.FormattingEnabled = true;
            this.cmb_2.Location = new System.Drawing.Point(289, 104);
            this.cmb_2.Name = "cmb_2";
            this.cmb_2.Size = new System.Drawing.Size(121, 26);
            this.cmb_2.TabIndex = 26;
            // 
            // cmb_3
            // 
            this.cmb_3.FormattingEnabled = true;
            this.cmb_3.Location = new System.Drawing.Point(289, 147);
            this.cmb_3.Name = "cmb_3";
            this.cmb_3.Size = new System.Drawing.Size(121, 26);
            this.cmb_3.TabIndex = 27;
            // 
            // cmb_4
            // 
            this.cmb_4.FormattingEnabled = true;
            this.cmb_4.Location = new System.Drawing.Point(289, 190);
            this.cmb_4.Name = "cmb_4";
            this.cmb_4.Size = new System.Drawing.Size(121, 26);
            this.cmb_4.TabIndex = 28;
            // 
            // cmb_5
            // 
            this.cmb_5.FormattingEnabled = true;
            this.cmb_5.Location = new System.Drawing.Point(289, 233);
            this.cmb_5.Name = "cmb_5";
            this.cmb_5.Size = new System.Drawing.Size(121, 26);
            this.cmb_5.TabIndex = 29;
            // 
            // cmb_6
            // 
            this.cmb_6.FormattingEnabled = true;
            this.cmb_6.Location = new System.Drawing.Point(289, 276);
            this.cmb_6.Name = "cmb_6";
            this.cmb_6.Size = new System.Drawing.Size(121, 26);
            this.cmb_6.TabIndex = 30;
            // 
            // cmb_7
            // 
            this.cmb_7.FormattingEnabled = true;
            this.cmb_7.Location = new System.Drawing.Point(289, 319);
            this.cmb_7.Name = "cmb_7";
            this.cmb_7.Size = new System.Drawing.Size(121, 26);
            this.cmb_7.TabIndex = 0;
            // 
            // cmb_14
            // 
            this.cmb_14.FormattingEnabled = true;
            this.cmb_14.Location = new System.Drawing.Point(441, 319);
            this.cmb_14.Name = "cmb_14";
            this.cmb_14.Size = new System.Drawing.Size(121, 26);
            this.cmb_14.TabIndex = 31;
            // 
            // cmb_13
            // 
            this.cmb_13.FormattingEnabled = true;
            this.cmb_13.Location = new System.Drawing.Point(441, 276);
            this.cmb_13.Name = "cmb_13";
            this.cmb_13.Size = new System.Drawing.Size(121, 26);
            this.cmb_13.TabIndex = 37;
            // 
            // cmb_12
            // 
            this.cmb_12.FormattingEnabled = true;
            this.cmb_12.Location = new System.Drawing.Point(441, 233);
            this.cmb_12.Name = "cmb_12";
            this.cmb_12.Size = new System.Drawing.Size(121, 26);
            this.cmb_12.TabIndex = 36;
            // 
            // cmb_11
            // 
            this.cmb_11.FormattingEnabled = true;
            this.cmb_11.Location = new System.Drawing.Point(441, 190);
            this.cmb_11.Name = "cmb_11";
            this.cmb_11.Size = new System.Drawing.Size(121, 26);
            this.cmb_11.TabIndex = 35;
            // 
            // cmb_10
            // 
            this.cmb_10.FormattingEnabled = true;
            this.cmb_10.Location = new System.Drawing.Point(441, 147);
            this.cmb_10.Name = "cmb_10";
            this.cmb_10.Size = new System.Drawing.Size(121, 26);
            this.cmb_10.TabIndex = 34;
            // 
            // cmb_9
            // 
            this.cmb_9.FormattingEnabled = true;
            this.cmb_9.Location = new System.Drawing.Point(441, 104);
            this.cmb_9.Name = "cmb_9";
            this.cmb_9.Size = new System.Drawing.Size(121, 26);
            this.cmb_9.TabIndex = 33;
            // 
            // cmb_8
            // 
            this.cmb_8.FormattingEnabled = true;
            this.cmb_8.Location = new System.Drawing.Point(441, 61);
            this.cmb_8.Name = "cmb_8";
            this.cmb_8.Size = new System.Drawing.Size(121, 26);
            this.cmb_8.TabIndex = 32;
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Location = new System.Drawing.Point(180, 369);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(54, 18);
            this.lbl_result.TabIndex = 38;
            this.lbl_result.Text = "label4";
            this.lbl_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_result
            // 
            this.txt_result.Location = new System.Drawing.Point(289, 366);
            this.txt_result.Name = "txt_result";
            this.txt_result.Size = new System.Drawing.Size(121, 28);
            this.txt_result.TabIndex = 39;
            // 
            // btn_result
            // 
            this.btn_result.Location = new System.Drawing.Point(441, 366);
            this.btn_result.Name = "btn_result";
            this.btn_result.Size = new System.Drawing.Size(121, 28);
            this.btn_result.TabIndex = 40;
            this.btn_result.Text = "button1";
            this.btn_result.UseVisualStyleBackColor = true;
            this.btn_result.Click += new System.EventHandler(this.btn_result_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_result);
            this.Controls.Add(this.txt_result);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.cmb_14);
            this.Controls.Add(this.cmb_13);
            this.Controls.Add(this.cmb_12);
            this.Controls.Add(this.cmb_11);
            this.Controls.Add(this.cmb_10);
            this.Controls.Add(this.cmb_9);
            this.Controls.Add(this.cmb_8);
            this.Controls.Add(this.cmb_7);
            this.Controls.Add(this.cmb_6);
            this.Controls.Add(this.cmb_5);
            this.Controls.Add(this.cmb_4);
            this.Controls.Add(this.cmb_3);
            this.Controls.Add(this.cmb_2);
            this.Controls.Add(this.cmb_1);
            this.Controls.Add(this.txt_course7);
            this.Controls.Add(this.txt_course4);
            this.Controls.Add(this.txt_course6);
            this.Controls.Add(this.txt_course5);
            this.Controls.Add(this.txt_course3);
            this.Controls.Add(this.txt_course2);
            this.Controls.Add(this.txt_course1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_course1;
        private System.Windows.Forms.TextBox txt_course2;
        private System.Windows.Forms.TextBox txt_course3;
        private System.Windows.Forms.TextBox txt_course5;
        private System.Windows.Forms.TextBox txt_course6;
        private System.Windows.Forms.TextBox txt_course4;
        private System.Windows.Forms.TextBox txt_course7;
        private System.Windows.Forms.ComboBox cmb_1;
        private System.Windows.Forms.ComboBox cmb_2;
        private System.Windows.Forms.ComboBox cmb_3;
        private System.Windows.Forms.ComboBox cmb_4;
        private System.Windows.Forms.ComboBox cmb_5;
        private System.Windows.Forms.ComboBox cmb_6;
        private System.Windows.Forms.ComboBox cmb_7;
        private System.Windows.Forms.ComboBox cmb_14;
        private System.Windows.Forms.ComboBox cmb_13;
        private System.Windows.Forms.ComboBox cmb_12;
        private System.Windows.Forms.ComboBox cmb_11;
        private System.Windows.Forms.ComboBox cmb_10;
        private System.Windows.Forms.ComboBox cmb_9;
        private System.Windows.Forms.ComboBox cmb_8;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.TextBox txt_result;
        private System.Windows.Forms.Button btn_result;
    }
}

